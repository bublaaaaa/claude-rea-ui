HOW TO USE (IMAGE SWAP VERSION)
1. Extract this ZIP.
2. Upload the three PNG guide sheets plus your own replacement character image to your image-generation AI.
3. Copy the complete contents of "prompt image swap.txt" into the message and ask the AI to generate the sequence sheet.
4. The AI should infer and match your character image's style automatically: its specific anime/illustration style, photorealism, or another supplied style.

THE THREE GUIDE SHEETS (all 6791 x 2266 px, 10 columns x 5 rows, 678 x 452 tiles, 1-pixel black grid lines)
grid-sheet.png          blank white tiles - the fixed canvas
reference-sheet.png     the 50 reference frames, one per tile
hand-blocking-sheet.png black hand shapes on white - where hands and forearms may appear (frames 02-12, 26-29, 42-45)

OUTPUT SIZE: the generated sheet may be bigger or smaller than the guides, as long as it keeps 10 x 5 equal tiles, every tile exactly 3:2, uniform thin black grid lines, and the same overall shape. The file must be below 24 MB.

Your replacement character is not included in this package. Supply it separately. A clear image works as the main reference; optional side and three-quarter views can help preserve identity during turns. Use consistent character references.

If your AI can read ZIP attachments, you may upload this ZIP with your character image and ask it to read "prompt image swap.txt" and use the three included PNG guides. If it cannot inspect ZIP contents, extract and upload the files individually.

After generation, still check that every tile is 3:2, the grid is 10 x 5, the file is below 24 MB, and the 50 frames are consistent. This package contains instructions and original guides, not a generated sequence.
